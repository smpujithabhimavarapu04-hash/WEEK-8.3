# JavaFX Tip Calculator — Experiment 3.1

## Aim
Build a JavaFX tip calculator with bill amount and tip percentage inputs, a Calculate Tip button, validation, result display, and Reset button.

## Project files
- `src/main/java/com/example/tipcalculator/TipCalculatorApp.java` — launches the JavaFX application.
- `src/main/java/com/example/tipcalculator/TipCalculatorController.java` — handles calculation, validation, and reset.
- `src/main/resources/com/example/tipcalculator/tip_calculator.fxml` — GUI layout.

## Run in IntelliJ IDEA
1. Create/open a JavaFX project configured with JavaFX.
2. Copy the `src` folder from this package into the project.
3. Ensure JavaFX Controls and FXML modules are included in the project configuration.
4. Run `TipCalculatorApp.java`.

## Calculation example
Bill Amount: `50.00`
Tip Percentage: `15`
Result: `Tip Amount: $7.50`

## Validation
- Non-numeric values display an error message.
- Negative values are rejected.
- Reset clears both input fields and result/error labels.

## Note
JavaFX must be installed/configured in your IDE. This package contains the Java source and FXML files; it does not bundle the JavaFX SDK.
